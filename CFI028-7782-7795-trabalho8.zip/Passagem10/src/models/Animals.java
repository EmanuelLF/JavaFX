/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import javafx.collections.ObservableList;

/**
 *
 * @author T-Gamer
 */
public class Animals {
    int id, idade;
    String nome, raca, tipo;

    public Animals(int id, int idade, String nome, String raca, String tipo) {
        this.id = id;
        this.idade = idade;
        this.nome = nome;
        this.raca = raca;
        this.tipo = tipo;
    }

    public Animals() {
    }

//    public Animals(String text, String text0, ObservableList<String> items, int parseInt) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Animals{" + "id=" + id + ", idade=" + idade + ", nome=" + nome + ", raca=" + raca + ", tipo=" + tipo + '}';
    }
    
    
    
}
