/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author T-Gamer
 */
public class AnimalsHolder {
      private Animals user;
  private final static AnimalsHolder instance = new AnimalsHolder();
  
  private AnimalsHolder() {}
  
  public static AnimalsHolder getInstance() {
    return instance;
  }
  
  public void setUser(Animals u) {
    this.user = u;
  }
  
  public Animals getUser() {
    return this.user;
  }
}

