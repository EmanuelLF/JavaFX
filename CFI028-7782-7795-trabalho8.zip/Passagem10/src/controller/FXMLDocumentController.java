/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import models.Animals;
import models.AnimalsHolder;
import java.io.IOException;
import java.net.URL;
import java.util.Collection;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 *
 * @author T-Gamer
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private TextField txtraca;
    @FXML
    private TextField txtnome;
    @FXML
    private TextField txtidade;
    @FXML
    private TextField txtid;
    @FXML
    private ComboBox<String> txttipo;
    @FXML
    private Button btnexit;
    @FXML
    private Button btnclear;
    @FXML
    private Button btnadd;
    
    final ObservableList <String>  comb = FXCollections.observableArrayList("gato","cao","passaro","roedores","reptil");

   
    
    public static Integer idade, id;
    public static String nome, raca, tipo;

    public Animals animals = new Animals();
    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {
        idade = Integer.parseInt(txtidade.getText());
        id = Integer.parseInt(txtid.getText());
        nome = txtnome.getText();
        raca = txtraca.getText();
        tipo =txttipo.getSelectionModel().getSelectedItem();
                Animals animals = new Animals(Integer.parseInt(txtid.getText()),Integer.parseInt(txtidade.getText()), txtnome.getText(), txtraca.getText(), txttipo.getSelectionModel().getSelectedItem());
        Node node = (Node) event.getSource();
        
        
        Stage stage=(Stage) node.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/view/resultados.fxml"));
        Parent root = loader.load();
        ResultadosController controller = loader.getController();
        AnimalsHolder holder = AnimalsHolder.getInstance();
        holder.setUser(animals);
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        

    }
    public void initialize(URL url, ResourceBundle rb) {

        txttipo.setItems(comb);
        btnexit.setOnAction((ActionEvent event)->{
    System.exit(0);
    });

//        txttipo.getItems().addAll("gato","cao","passaro","roedores","reptil");
            
        }

    @FXML
    private void limpar(ActionEvent event) {
        Object botaoclicado = event.getSource();
            
             if (botaoclicado == btnclear){
            txtidade.clear();
            txtid.clear();
            txttipo.getSelectionModel().clearSelection();
            txtnome.clear();
            txtnome.requestFocus();
            txtraca.clear();
             }
    }
        
        
   
    
}
