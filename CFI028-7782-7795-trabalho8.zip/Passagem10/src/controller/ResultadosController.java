package controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class ResultadosController implements Initializable {

    @FXML
    private Label resulnome;
    @FXML
    private Label resulidade;
    @FXML
    private Label resultipo;
    @FXML
    private Label resulraca;
    @FXML
    private Label resulid;
    @FXML
    private Button btnexit;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        resulnome.setText(FXMLDocumentController.nome);
        resulid.setText(Integer.toString(FXMLDocumentController.id));
        resulidade.setText(Integer.toString(FXMLDocumentController.idade));
        resulraca.setText(FXMLDocumentController.raca);
        resultipo.setText(FXMLDocumentController.tipo);
        
        btnexit.setOnAction((ActionEvent event)->{
    System.exit(0);
    });
    }    
    
}