package newpackage;

public class Professores {
    String CPF,Nome,Endereco,Cidade,CEP,Telefone; 

    @Override
    public String toString() {
        return "Professores{" + "CPF=" + CPF + ", Nome=" + Nome + '}';
    }

    public Professores(String CPF, String Nome, String Endereco, String Cidade, String CEP, String Telefone) {
        this.CPF = CPF;
        this.Nome = Nome;
        this.Endereco = Endereco;
        this.Cidade = Cidade;
        this.CEP = CEP;
        this.Telefone = Telefone;
    }

    public Professores() {
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getEndereco() {
        return Endereco;
    }

    public void setEndereco(String Endereco) {
        this.Endereco = Endereco;
    }

    public String getCidade() {
        return Cidade;
    }

    public void setCidade(String Cidade) {
        this.Cidade = Cidade;
    }

    public String getCEP() {
        return CEP;
    }

    public void setCEP(String CEP) {
        this.CEP = CEP;
    }

    public String getTelefone() {
        return Telefone;
    }

    public void setTelefone(String Telefone) {
        this.Telefone = Telefone;
    }

    
    
}
