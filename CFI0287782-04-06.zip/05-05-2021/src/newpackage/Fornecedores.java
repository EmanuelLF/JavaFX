package newpackage;

public class Fornecedores {
    String CNPJ, nomeComercial, contato, endereco, cidade, cep, telefone,ramo;

    public Fornecedores(String CNPJ, String nomeComercial, String contato, String endereco, String cidade, String cep, String telefone, String ramo) {
        this.CNPJ = CNPJ;
        this.nomeComercial = nomeComercial;
        this.contato = contato;
        this.endereco = endereco;
        this.cidade = cidade;
        this.cep = cep;
        this.telefone = telefone;
        this.ramo = ramo;
    }

    public Fornecedores() {
    }

    public Fornecedores(String CNPJ, String nomeComercial, String contato, String cidade, String telefone, String ramo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    

    @Override
    public String toString() {
        return "Fornecedores{" + "CNPJ=" + CNPJ + ", nomeComercial=" + nomeComercial + ", contato=" + contato + ", endereco=" + endereco + ", cidade=" + cidade + ", cep=" + cep + ", telefone=" + telefone + ", ramo=" + ramo + '}';
    }

    public String getCNPJ() {
        return CNPJ;
    }

    public void setCNPJ(String CNPJ) {
        this.CNPJ = CNPJ;
    }

    public String getNomeComercial() {
        return nomeComercial;
    }

    public void setNomeComercial(String nomeComercial) {
        this.nomeComercial = nomeComercial;
    }

    public String getContato() {
        return contato;
    }

    public void setContato(String contato) {
        this.contato = contato;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getRamo() {
        return ramo;
    }

    public void setRamo(String ramo) {
        this.ramo = ramo;
    }
    
    
}
