/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa;

import Controller.Main;
import Controller.Mascaras;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import newpackage.Professores;

/**
 * FXML Controller class
 *
 * @author T-Gamer
 */
public class ProfessoresController implements Initializable {

    @FXML
    private TextField txcpf;
    @FXML
    private TextField txnome;
    @FXML
    private TextField txtender;
    @FXML
    private TextField txtcida;
    @FXML
    private TextField txtcep;
    @FXML
    private TextField txttell;
    @FXML
    private Button btnConfirmar;
    @FXML
    private Button btnApagar;
    @FXML
    private Button btnSair;
    @FXML
    private ListView<Professores> lvwPROF;
    
    final ObservableList<Professores> ListProfessores = FXCollections.observableArrayList();
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        btnSair.setOnAction((ActionEvent event)->{
    Main.trocatela("inicial");
    });     
        txcpf.setOnKeyPressed(event ->{
    Mascaras.mascaraCPF(txcpf);
    });
                
        txtcep.setOnKeyPressed(event ->{
    Mascaras.mascaraCEP(txtcep);
    });
        
        txttell.setOnKeyPressed(event ->{
    Mascaras.mascaraTelefone(txttell);
    });
        
         lvwPROF.setItems(ListProfessores);
         
       
        
    }    

    @FXML
    private void OnCONFIRMAR(ActionEvent event) {
        String CPF,Nome,Endereco,Cidade,CEP,Telefone; 
        
        CPF=txcpf.getText();
        Nome=txnome.getText();
        Endereco=txtender.getText();
        Cidade=txtcida.getText();
        CEP=txtcep.getText();
        Telefone=txttell.getText();
        
        Professores Prof = new Professores(CPF,Nome,Endereco,Cidade,CEP,Telefone);
        ListProfessores.add(Prof);
        
        txcpf.clear();
        txnome.clear();
        txtender.clear();
        txtcida.clear();        
        txtcep.clear();        
        txttell.clear();        
        txcpf.requestFocus();
    }

    @FXML
    private void OnAPAGAR(ActionEvent event) {
        System.out.println(lvwPROF.getSelectionModel().getSelectedItem());
        System.out.println(lvwPROF.getSelectionModel().getSelectedIndex());
        //String prof = lvwPROF.getSelectionModel().getSelectedItem();
        int posicao=lvwPROF.getSelectionModel().getSelectedIndex();
        ListProfessores.remove(posicao);
    }
    
}
