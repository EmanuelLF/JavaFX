/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa;

import Controller.Main;
import Controller.Mascaras;
import java.awt.Image;
import java.io.FileInputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javax.imageio.stream.FileCacheImageInputStream;
import static jdk.nashorn.tools.ShellFunctions.input;
import newpackage.Fornecedores;

/**
 * FXML Controller class
 *
 * @author T-Gamer
 */
public class FornecedoresController implements Initializable {

    @FXML
    private TextField txtCNPJ;
    @FXML
    private TextField txtNome;
    @FXML
    private TextField txtCont;
    @FXML
    private TextField txtEnder;
    @FXML
    private TextField txtCidade;
    @FXML
    private TextField txtCep;
    @FXML
    private TextField txtTell;
    @FXML
    private ComboBox<String> cbSelect;
    @FXML
    private Button btnAdicionar;
    @FXML
    private Button btnApagar;
    @FXML
    private Button btnSair;
    @FXML
    private TableView<Fornecedores> tblforne;
    @FXML
    private TableColumn<Fornecedores, String> tblforneCNPJ;
    @FXML
    private TableColumn<Fornecedores, String> tblforneNOME;
    @FXML
    private TableColumn<Fornecedores, String> tblforneCTT;
    @FXML
    private TableColumn<Fornecedores, String> tblforneCITY;
    @FXML
    private TableColumn<Fornecedores, String> tblforneTELL;
    @FXML
    private TableColumn<Fornecedores, ComboBox> tblforneRAMO;
    final ObservableList<Fornecedores> obsForne = FXCollections.observableArrayList();
    @FXML
    private Button btnSELECT;
    @FXML
    private ImageView imgfornec;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        btnSair.setOnAction((ActionEvent event)->{
    Main.trocatela("inicial");
    });  
        
        txtCNPJ.setOnKeyPressed(event ->{
    Mascaras.mascaraCNPJ(txtCNPJ);
    });
                
        txtCep.setOnKeyPressed(event ->{
    Mascaras.mascaraCEP(txtCep);
    });
        
        txtTell.setOnKeyPressed(event ->{
    Mascaras.mascaraTelefone(txtTell);
    });
        
        cbSelect.getItems().addAll("Limpeza","Imprensa","Cantina","Consultoria");
    
    tblforneCNPJ.setCellValueFactory(new PropertyValueFactory<>("CNPJ"));
    tblforneNOME.setCellValueFactory(new PropertyValueFactory<>("nomeComercial"));
    tblforneCTT.setCellValueFactory(new PropertyValueFactory<>("contato"));
    tblforneCITY.setCellValueFactory(new PropertyValueFactory<>("cidade"));
    tblforneTELL.setCellValueFactory(new PropertyValueFactory<>("telefone"));
    tblforneRAMO.setCellValueFactory(new PropertyValueFactory<>("ramo"));
    
        tblforne.setItems(obsForne);
    
    }    
    
    @FXML
    private void ADD(ActionEvent event) {
        
        String CNPJ, nomeComercial, contato, cidade, telefone,ramo;
        
        CNPJ=txtCNPJ.getText();
        nomeComercial=txtNome.getText();
        contato=txtCont.getText();
        cidade=txtCidade.getText();
        telefone=txtTell.getText();
        ramo=cbSelect.getSelectionModel().getSelectedItem();
        
        Fornecedores fornec = new Fornecedores(CNPJ,nomeComercial,contato,cidade,telefone,ramo);
        
        obsForne.add(fornec);   
    }

    @FXML
    private void LIMPAR(ActionEvent event) {
        
        int selectedIndex = tblforne.getSelectionModel().getSelectedIndex();
        if (selectedIndex>=0){
        Fornecedores fornec = new Fornecedores();
        //fornec = tblforne.getSelectionModel().getSelectedItem();
        obsForne.remove(selectedIndex);
        
        }else{
        Alert dialogoErro = new Alert(Alert.AlertType.ERROR);
         dialogoErro.setTitle("Diálogo de Erro");
         dialogoErro.setHeaderText("Remoção de Ítens...");
         dialogoErro.setContentText("Atenção: Não há items para serem removidos!");
         dialogoErro.showAndWait();
        }

                
        
    }

    @FXML
    private void SELECT(ActionEvent event) {
        
        int selectedIndex = tblforne.getSelectionModel().getSelectedIndex();
        if (selectedIndex>=0){
        Fornecedores fornec = new Fornecedores();
        fornec = tblforne.getSelectionModel().getSelectedItem();
        
        
        txtCNPJ.setText(fornec.getCNPJ());
        txtNome.setText(fornec.getNomeComercial());
        txtCont.setText(fornec.getContato());
        txtCidade.setText(fornec.getCidade());
        txtTell.setText(fornec.getTelefone());
        cbSelect.getSelectionModel().select(fornec.getRamo());
            System.out.println("C:\\Users\\T-Gamer\\Desktop"+fornec.getRamo()+".jpg");
            try {
                
            FileInputStream input = new FileInputStream("C:\\Users\\T-Gamer\\Desktop"+fornec.getRamo()+".jpg");
                
            javafx.scene.image.Image image = new javafx.scene.image.Image(input);
            imgfornec.setPreserveRatio(true);
            imgfornec.setFitHeight(128); 
            imgfornec.setFitWidth(72); 

            imgfornec.setImage(image);
            }catch (Exception e){
                
            }
        }else{
        Alert dialogoErro = new Alert(Alert.AlertType.ERROR);
         dialogoErro.setTitle("Diálogo de Erro");
         dialogoErro.setHeaderText("Seleção de Itens");
         dialogoErro.setContentText("Atenção: Não há items para serem selecionados!");
         dialogoErro.showAndWait();
        }

    }

    @FXML
    private void tblCliket(MouseEvent event) {
        
        int selectedIndex = tblforne.getSelectionModel().getSelectedIndex();
        if (selectedIndex>=0){
        Fornecedores fornec = new Fornecedores();
        fornec = tblforne.getSelectionModel().getSelectedItem();
        
        
        txtCNPJ.setText(fornec.getCNPJ());
        txtNome.setText(fornec.getNomeComercial());
        txtCont.setText(fornec.getContato());
        txtCidade.setText(fornec.getCidade());
        txtTell.setText(fornec.getTelefone());
        cbSelect.getSelectionModel().select(fornec.getRamo());
        }else{
        Alert dialogoErro = new Alert(Alert.AlertType.ERROR);
         dialogoErro.setTitle("Diálogo de Erro");
         dialogoErro.setHeaderText("Seleção de Itens");
         dialogoErro.setContentText("Atenção: Não há items para serem selecionados!");
         dialogoErro.showAndWait();
        }
    }
    
    public void CaixaErro(String titulo, String cabecalho, String texto) {
         
         Alert dialogoErro = new Alert(Alert.AlertType.ERROR);
         dialogoErro.setTitle(titulo);
         dialogoErro.setHeaderText(cabecalho);
         dialogoErro.setContentText(texto);
         dialogoErro.showAndWait();
    }

}