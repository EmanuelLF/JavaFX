/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author T-Gamer
 */
public class Main extends Application {
    
    private static Scene inicial;
    private static Scene professores;
    private static Scene fornecedores;
    
    private static Stage palco;
    
    @Override
    public void start(Stage stage) throws Exception {
        palco=stage;
        Parent root = FXMLLoader.load(getClass().getResource("/view/FXMLDocument.fxml"));
        inicial= new Scene (root);
        
        Parent prof = FXMLLoader.load(getClass().getResource("/view/Professores.fxml"));
        professores = new Scene (prof);
        
        Parent forne = FXMLLoader.load(getClass().getResource("/view/Fornecedores.fxml"));
        fornecedores = new Scene (forne);
        
        palco.setScene(inicial);
        palco.show();
    }
    public static void trocatela(String nomeDaCena){
    switch (nomeDaCena){
        case "inicial":
            palco.setScene(inicial);
            break;
        case "prof":
            palco.setScene(professores);
            break;
        case "forne":
            palco.setScene(fornecedores);
            break;   
        }  
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
