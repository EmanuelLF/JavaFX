/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg1905;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

/**
 *
 * @author T-Gamer
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private Button btnHome;
    @FXML
    private Button btnNext;
    @FXML
    private Button btnExit;
    
    private void handleButtonAction(ActionEvent event) {
        
        
        
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
                btnNext.setOnAction((ActionEvent event)->{
    Main.trocatela("Add");
    });
                btnExit.setOnAction((ActionEvent event)->{
    System.exit(0);
    });
    }
    
}
