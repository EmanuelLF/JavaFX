package pkg1905;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
 

public class Main extends Application {
    
    private static Scene inicial;
    private static Scene add;
    
    private static Stage palco;

    @Override
    public void start(Stage stage) throws Exception {
        palco=stage;
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        inicial= new Scene (root);
        
        Parent Add = FXMLLoader.load(getClass().getResource("add.fxml"));
        add = new Scene (Add);
        
        palco.setScene(inicial);
        palco.show();
    }
    public static void trocatela(String nomeDaCena){
    switch (nomeDaCena){
        case "inicial":
            palco.setScene(inicial);
            break;
        case "Add":
            palco.setScene(add);
            break;
        }  
    }
    
    public static void main(String[] args) {
        launch(args);
    }
    
}
