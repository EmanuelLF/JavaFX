/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg1905;

/**
 *
 * @author T-Gamer
 */
public class add {
    String nome,Npag,ISPN,autor;

    public add(String nome, String Npag, String ISPN, String autor) {
        this.nome = nome;
        this.Npag = Npag;
        this.ISPN = ISPN;
        this.autor = autor;
    }

        public add() {
    }

    
    @Override
    public String toString() {
        return "nome do livro=" + nome + ", Npag=" + Npag + ", ISPN=" + ISPN + ", autor=" + autor + '}';
    }
    
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNpag() {
        return Npag;
    }

    public void setNpag(String Npag) {
        this.Npag = Npag;
    }

    public String getISPN() {
        return ISPN;
    }

    public void setISPN(String ISPN) {
        this.ISPN = ISPN;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }
    
}
