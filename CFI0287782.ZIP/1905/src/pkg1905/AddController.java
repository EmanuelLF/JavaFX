/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg1905;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Driver;
import static java.lang.Class.forName;
import java.net.URL;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author T-Gamer
 */
public class AddController implements Initializable {

    @FXML
    private TextField txtNome;
    @FXML
    private TextField txtNP;
    @FXML
    private TextField txtN;
    @FXML
    private TextField txtAutor;
    @FXML
    private Button btnSubmit;
    @FXML
    private Button btnHome;

    
    final ObservableList<add> tit = FXCollections.observableArrayList();
    @FXML
    private Label lbl01;
    
    @FXML
    private void handleButtonAction (ActionEvent event){
             
     String ISBN = txtN.getText();
     int PG = Integer.parseInt(txtNP.getText());
     String Nome = txtNome.getText();
     String Autor = txtAutor.getText();
     try {
         Class.forName("com.mysql.jdbc.Driver");
         String URL = "jdbc:mysql://localhost:3306/firstConection";
         String usuario = "root";
         String senha = "";
         Connection conexao = (Connection) DriverManager.getConnection(URL,usuario,senha);
         //Descreição do erro ->com.mysql.jdbc.MysqlDataTruncation: Data truncation: 
        //Incorrect integer value: 'efefsed' for column `firstconection`.`acervo`.`Número de Páginas` at row 1
         String sql = "insert into acervo values (?,?,?,?);";
         PreparedStatement comando = conexao.prepareStatement(sql);
         comando.setString(1,Nome);
         comando.setString(4,Autor);
         comando.setString(3,ISBN);
         comando.setInt(2, PG);  
         
         comando.executeUpdate();
         comando.close();
         conexao.close();
         lbl01.setText("Gravado com sucesso!");
         
     }catch(Exception erro){
         lbl01.setText("Erro na gravação");
         System.out.println("Descreição do erro ->" + erro);
     }
}
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
                btnHome.setOnAction((ActionEvent event)->{
    Main.trocatela("inicial");
    });
    }    
      
       
}

