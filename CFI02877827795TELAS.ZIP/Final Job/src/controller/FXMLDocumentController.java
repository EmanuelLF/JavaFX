/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Ctrl.ControleCarro;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import model.carros;
import pkgfinal.job.FinalJob;

/**
 *
 * @author T-Gamer
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private TextField txtano;
    @FXML
    private Button btnhome;
    @FXML
    private Button btnadd;
    @FXML
    private Button btnlimpar;
    @FXML
    private TextField txtID;
    @FXML
    private TextField txtmarca;
    @FXML
    private TextField txtgeral;
    @FXML
    private TextField txtdescriçâo;
    @FXML
    private TextField txtvalor;
    @FXML
    private TextField txtestado;
    @FXML
    private TextField txtmodelo;
    @FXML
    private TableColumn<carros, Integer> tblid;
    @FXML
    private TableColumn<carros, String> tblmodelo;
    @FXML
    private TableColumn<carros, Integer> tblano;
    @FXML
    private TableColumn<carros, Float> tblpreco;
    @FXML
    private TableView<carros> tbwcarros;
    
    private ObservableList<carros> observableListCarros;
    private List<carros> listCarro = new ArrayList<carros>();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
                
        try {
            listarCarros();
            limparCampos();
            configurarTabela();
            txtID.requestFocus();
            txtID.setText("");
        } catch (Exception ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        btnhome.setOnAction((ActionEvent event)->{
            FinalJob.trocatela("home");
            });
    }    

    public void listarCarros() throws Exception {
        configurarTabela();
        ControleCarro controle = new ControleCarro();
        listCarro = controle.listarCarros();
        observableListCarros = FXCollections.observableArrayList(listCarro);
        tbwcarros.setItems(observableListCarros);
    }
        
    private void limparCampos() {
        txtID.setText("");
        txtmarca.setText("");
        txtgeral.setText("");
        txtdescriçâo.setText("");
        txtvalor.setText("");
        txtestado.setText("");
        txtmodelo.setText("");
        txtID.requestFocus();
        txtID.setText("");
    }
        private void configurarTabela() {
        tblid.setCellValueFactory(new PropertyValueFactory<>("ID"));
        tblmodelo.setCellValueFactory(new PropertyValueFactory<>("Modelo"));
        tblano.setCellValueFactory(new PropertyValueFactory<>("Ano"));
        tblpreco.setCellValueFactory(new PropertyValueFactory<>("Preço"));
    }
    
    @FXML
    private void add(ActionEvent event) throws Exception {
        carros c = new carros();
                Integer.parseInt(txtID.getText()); 
                        txtdescriçâo.getText();
                        txtgeral.getText(); 
                        Integer.parseInt(txtano.getText()); 
                        txtmarca.getText(); 
                        txtmodelo.getText();
                        txtestado.getText();
                        Float.parseFloat(txtvalor.getText());
        ControleCarro carro = new ControleCarro();
        observableListCarros.add(c);
        carro.inserirCarro(c);
        limparCampos();
    }

    @FXML
    private void clear(ActionEvent event) {
        
        Object botaoclicado = event.getSource();
            
             if (botaoclicado == btnlimpar){
            txtano.clear();
            txtID.clear();
            txtmarca.clear();
            txtgeral.clear();
            txtdescriçâo.clear();
            txtvalor.clear();
            txtestado.clear();
            txtmodelo.clear();
            txtID.requestFocus();
        }
    }
}