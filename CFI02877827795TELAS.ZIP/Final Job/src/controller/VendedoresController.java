package controller;

import Ctrl.ControleVendedore;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import model.vendedores;
import pkgfinal.job.FinalJob;

public class VendedoresController implements Initializable {

    @FXML
    private TextField txtidvendedores;
    @FXML
    private TextField txtdescriçâovendedores;
    @FXML
    private Button btnhome;
    @FXML
    private Button btnadd;
    @FXML
    private Button btnlimpar;
    @FXML
    private TableColumn<vendedores, Integer> tblid;
    @FXML
    private TableColumn<vendedores, String> tbldescricao;
    @FXML
    private TableView<vendedores> tbwvendedores;

        private ObservableList<vendedores> observableListvendedo;
    private List<vendedores> listVendedo = new ArrayList<vendedores>();
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
                
        try {
            listarVendedores();
            limparCampos();
            configurarTabela();
            txtidvendedores.requestFocus();
            txtidvendedores.setText("");
        } catch (Exception ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        btnhome.setOnAction((ActionEvent event)->{
            FinalJob.trocatela("home");
            });
    }    

        public void listarVendedores() throws Exception {
        configurarTabela();
            ControleVendedore controle = new ControleVendedore();
        listVendedo = controle.listarCarros();
        observableListvendedo = FXCollections.observableArrayList(listVendedo);
        tbwvendedores.setItems(observableListvendedo);
    }
        
    private void limparCampos() {
        txtidvendedores.setText("");
        txtdescriçâovendedores.setText("");
        txtidvendedores.requestFocus();
        txtidvendedores.setText("");
    }
        private void configurarTabela() {
        tblid.setCellValueFactory(new PropertyValueFactory<>("ID"));
        tbldescricao.setCellValueFactory(new PropertyValueFactory<>("DESCRIÇÃO"));
    }
    
    @FXML
    private void add(ActionEvent event) throws Exception {
                
        vendedores c = new vendedores();
                Integer.parseInt(txtidvendedores.getText()); 
                        txtdescriçâovendedores.getText();
        ControleVendedore vendedo = new ControleVendedore();
        observableListvendedo.add(c);
        vendedo.inserirVendedor(c);
        limparCampos();
    }

    @FXML
    private void clear(ActionEvent event) {
            
        Object botaoclicado = event.getSource();
            
             if (botaoclicado == btnlimpar){
            txtidvendedores.clear();
            txtdescriçâovendedores.clear();
            txtidvendedores.requestFocus();
             }
    }
    
}
