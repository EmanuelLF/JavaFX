/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import pkgfinal.job.FinalJob;

/**
 * FXML Controller class
 *
 * @author T-Gamer
 */
public class VendasController implements Initializable {

    @FXML
    private TextField txtidvendas;
    @FXML
    private TextField cliente;
    @FXML
    private TextField vendedor;
    @FXML
    private TextField carro;
    @FXML
    private Button btnhome;
    @FXML
    private Button btnadd;
    @FXML
    private Button btnlimpar;
    @FXML
    private TableColumn<?, ?> tblid;
    @FXML
    private TableColumn<?, ?> tblcliente;
    @FXML
    private TableColumn<?, ?> tblcarro;
    @FXML
    private TableColumn<?, ?> tblvendedor;
    @FXML
    private TableView<?> tbwvendas;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
           
        btnhome.setOnAction((ActionEvent event)->{
            FinalJob.trocatela("home");
            });
    }    

    @FXML
    private void add(ActionEvent event) {
    }

    @FXML
    private void clear(ActionEvent event) {
        
        Object botaoclicado = event.getSource();
            
             if (botaoclicado == btnlimpar){
            txtidvendas.clear();
            cliente.clear();
            vendedor.clear();
            carro.clear();
            txtidvendas.requestFocus();
             }
    }
    
}
