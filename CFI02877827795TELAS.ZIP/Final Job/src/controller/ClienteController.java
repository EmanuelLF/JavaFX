/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Ctrl.ControleCliente;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import model.cliente;
import pkgfinal.job.FinalJob;

/**
 * FXML Controller class
 *
 * @author T-Gamer
 */
public class ClienteController implements Initializable {

    @FXML
    private TextField txtidcliente;
    @FXML
    private TextField txtdescriçâocliente;
    @FXML
    private TextField txtenderecocliente;
    @FXML
    private TextField txttelefonecliente;
    @FXML
    private Button btnhome;
    @FXML
    private Button btnadd;
    @FXML
    private Button btnlimpar;
    @FXML
    private TableColumn<cliente, Integer> tblid;
    @FXML
    private TableColumn<cliente, String> tbltelefone;
    @FXML
    private TableColumn<cliente, String> tblendereco;
    @FXML
    private TableView<cliente> tbwclientes;
    
    private ObservableList<cliente> observableListClints;
    private List<cliente> listClient = new ArrayList<cliente>();

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        try {
            listarClientes();
            limparCampos();
            configurarTabela();
            txtidcliente.requestFocus();
            txtidcliente.setText("");
        } catch (Exception ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        btnhome.setOnAction((ActionEvent event)->{
            FinalJob.trocatela("home");
            });
    }    

    public void listarClientes() throws Exception {
        configurarTabela();
        ControleCliente controle = new ControleCliente();
        listClient = controle.listarCliente();
        observableListClints = FXCollections.observableArrayList(listClient);
        tbwclientes.setItems(observableListClints);
    }
        
    private void limparCampos() {
        txtidcliente.setText("");
        txtdescriçâocliente.setText("");
        txtenderecocliente.setText("");
        txttelefonecliente.setText("");
        txtidcliente.requestFocus();
        txtidcliente.setText("");
    }
        private void configurarTabela() {
        tblid.setCellValueFactory(new PropertyValueFactory<>("ID"));
        tbltelefone.setCellValueFactory(new PropertyValueFactory<>("TELEFONE"));
        tblendereco.setCellValueFactory(new PropertyValueFactory<>("ENDEREÇO"));
    }
    
    @FXML
    private void add(ActionEvent event) throws Exception {
                cliente c = new cliente();
                        txtidcliente.getText(); 
                        txtdescriçâocliente.getText();
                        txtenderecocliente.getText(); 
                        txttelefonecliente.getText(); 
        ControleCliente clint = new ControleCliente();
        observableListClints.add(c);
        clint.inserirCliente(c);
        limparCampos();
    }

    @FXML
    private void clear(ActionEvent event) {
        
            Object botaoclicado = event.getSource();
            
             if (botaoclicado == btnlimpar){
            txtidcliente.clear();
            txtdescriçâocliente.clear();
            txtenderecocliente.clear();
            txttelefonecliente.clear();
            txtidcliente.requestFocus();
    }    
        
    }
    
}
