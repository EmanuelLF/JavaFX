/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfinal.job;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author T-Gamer
 */
public class FinalJob extends Application {
    
    private static Scene home;
    private static Scene vendedor;
    private static Scene vendas;
    private static Scene cliente;
    private static Scene carros;
    
    private static Stage palco;

//    private static Scene inicial;
//    private static Scene add;
//    
//    private static Stage palco;
    
    
    
    
    
    @Override
    public void start(Stage stage) throws Exception {
        palco = stage;
        Parent root = FXMLLoader.load(getClass().getResource("/view/home.fxml"));
        home= new Scene (root);
                
        Parent Vendedores = FXMLLoader.load(getClass().getResource("/view/Vendedores.fxml"));
        vendedor = new Scene (Vendedores);
        
        Parent Vendas = FXMLLoader.load(getClass().getResource("/view/Vendas.fxml"));
        vendas = new Scene (Vendas);
        
        Parent Carros = FXMLLoader.load(getClass().getResource("/view/FXMLDocument.fxml"));
        carros = new Scene (Carros);
        
        Parent Clientes = FXMLLoader.load(getClass().getResource("/view/cliente.fxml"));
        cliente = new Scene (Clientes);
        
        palco.setScene(home);
        palco.show();
    }
//        palco=stage;
//        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
//        inicial= new Scene (root);
//        
//        Parent Add = FXMLLoader.load(getClass().getResource("add.fxml"));
//        add = new Scene (Add);
//        
//        palco.setScene(inicial);
//        palco.show();
//    }
    public static void trocatela(String nomeDaCena){
    switch (nomeDaCena){
        case "home":
            palco.setScene(home);
            break;
        case "Vendedores":
            palco.setScene(vendedor);
            break;
        case "Vendas":
            palco.setScene(vendas);
            break;
        case "FXMLDocument":
            palco.setScene(carros);  
            break;
        case "clientes":
            palco.setScene(cliente);
            break;
        }  
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
