/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ctrl;

import DataBase.ConectVendedor;
import java.util.ArrayList;
import model.vendedores;
/**
 *
 * @author T-Gamer
 */
public class ControleVendedore {
        
     ConectVendedor vendedoresDAO = new ConectVendedor();

    public void inserirVendedor(vendedores vendedores) throws Exception {
        vendedoresDAO.inserirVendedor(vendedores);
    }

    public void apagarCarros(String id) throws Exception {
        vendedoresDAO.apagarVendedor(id);
    }

    public ArrayList<vendedores> listarCarros() throws Exception {
        ArrayList<vendedores> vendedoress = vendedoresDAO.listVendedores();
        return vendedoress;
    }
}
