package Ctrl;

import DataBase.ConectVeiculos;
import java.util.ArrayList;
import model.carros;

public class ControleCarro {

    ConectVeiculos veiculosDAO = new ConectVeiculos();

    public void inserirCarro(carros carros) throws Exception {
        veiculosDAO.inserirVeiculo(carros);
    }

    public void apagarCarros(String id) throws Exception {
        veiculosDAO.apagarVeiculo(id);
    }

    public ArrayList<carros> listarCarros() throws Exception {
        ArrayList<carros> carross = veiculosDAO.listCarro();
        return carross;
    }
}
