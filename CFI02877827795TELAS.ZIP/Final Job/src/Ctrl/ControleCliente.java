package Ctrl;

import DataBase.conectCliente;
import java.util.ArrayList;
import model.cliente;

public class ControleCliente {
        
    conectCliente clientesDAO = new conectCliente();

    public void inserirCliente(cliente cliente) throws Exception {
        clientesDAO.inserirCliente(cliente);
    }

    public void apagarCarros(String id) throws Exception {
        clientesDAO.apagarCliente(id);
    }

    public ArrayList<cliente> listarCliente() throws Exception {
        ArrayList<cliente> clientess = clientesDAO.listCliente();
        return clientess;
    }
}
