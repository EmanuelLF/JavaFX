package model;

public class carros {
    Integer id, ano;
    String descricao,geral,marca,modelo,estado;
    float valor;

//    public carros(Integer id, Integer ano, String descricao, String geral, String marca, String modelo, String estado, float valor) {
//        this.id = id;
//        this.ano = ano;
//        this.descricao = descricao;
//        this.geral = geral;
//        this.marca = marca;
//        this.modelo = modelo;
//        this.estado = estado;
//        this.valor = valor;
//    }

    public carros() {
    }

    public int getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(Integer ano) {
        this.ano = ano;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getGeral() {
        return geral;
    }

    public void setGeral(String geral) {
        this.geral = geral;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    @Override
    public String toString() {
        return "carros{" + "id=" + id + ", ano=" + ano + ", descricao=" + descricao + ", geral=" + geral + ", marca=" + marca + ", modelo=" + modelo + ", estado=" + estado + ", valor=" + valor + '}';
    }
    
}
