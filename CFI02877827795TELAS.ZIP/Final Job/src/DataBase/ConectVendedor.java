/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataBase;

import conecta.DAOz;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.vendedores;

/**
 *
 * @author T-Gamer
 */
public class ConectVendedor extends DAOz{
        public void inserirVendedor(vendedores a) throws Exception {
        conecta();
        statement = connection.prepareStatement("INSERT INTO vendedores VALUES (?, ?)");
        statement.setInt(1, a.getId());
        statement.setString(3, a.getDescricao());
        statement.execute();
        statement.close();
        fechaConexao();
    }
       
    public void apagarVendedor(String id) throws Exception {
        conecta();
        statement = connection.prepareStatement("DELETE FROM vendedores WHERE ID = ?");
        statement.setString(1, id);
        statement.execute();
        fechaConexao();
    }
    
        
    public ArrayList<vendedores> listVendedores() throws Exception {
        ArrayList listaVendedores = new ArrayList();
            conecta();
        statement = connection.prepareStatement("SELECT * FROM vendedores");
        ResultSet rs = statement.executeQuery();
        ArrayList<vendedores> b = new ArrayList<vendedores>();
        while (rs.next()) {
            vendedores a = new vendedores();

                a.setId(rs.getInt("ID")); 
                a.setDescricao(rs.getString("DESCRIÇÃO")); 
                listaVendedores.add(a);
            }
        
        rs.close();
        statement.close();
        fechaConexao();
        return b;
    }
}
