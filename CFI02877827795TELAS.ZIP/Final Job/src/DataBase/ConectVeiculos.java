package DataBase;

import conecta.DAOz;
import model.carros;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ConectVeiculos extends DAOz{
    
//        int id, ano;
//    String descricao,geral,marca,modelo,estado;
//    float valor;
    
       public void inserirVeiculo(carros a) throws Exception {
        conecta();
        statement = connection.prepareStatement("INSERT INTO carros VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        statement.setInt(1, a.getId());
        statement.setString(3, a.getDescricao());
        statement.setString(4, a.getGeral());
        statement.setInt(2, a.getAno());
        statement.setString(4, a.getMarca());
        statement.setString(4, a.getModelo());
        statement.setString(4, a.getEstado());
        statement.setFloat(4, a.getValor());
        statement.execute();
        statement.close();
        fechaConexao();
    }
       
        public void apagarVeiculo(String id) throws Exception {
        conecta();
        statement = connection.prepareStatement("DELETE FROM carros WHERE ID = ?");
        statement.setString(1, id);
        statement.execute();
        fechaConexao();
    }
        public ArrayList<carros> listCarro() throws Exception {
        ArrayList listaCarro = new ArrayList();
            conecta();
        statement = connection.prepareStatement("SELECT * FROM carros");
        ResultSet rs = statement.executeQuery();
        ArrayList<carros> carros  = new ArrayList<carros>();
        while (rs.next()) {
            carros a = new carros();
                a.setId(rs.getInt("id")); 
                a.setDescricao(rs.getString("descricao")); 
                a.setGeral(rs.getString("geral")); 
                a.setAno(rs.getInt("ano")); 
                a.setMarca(rs.getString("marca")); 
                a.setModelo(rs.getString("modelo")); 
                a.setEstado(rs.getString("estado")); 
                a.setValor(rs.getFloat("valor")); 
                listaCarro.add(a);
            }
        
        rs.close();
        statement.close();
        fechaConexao();
        return carros;
    }
        
}
