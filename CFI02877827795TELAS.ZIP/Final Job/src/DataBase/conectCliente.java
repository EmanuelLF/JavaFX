/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataBase;

import conecta.DAOz;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.cliente;

/**
 *
 * @author T-Gamer
 */
public class conectCliente extends DAOz{
           
    public void inserirCliente(cliente a) throws Exception {
        conecta();
        statement = connection.prepareStatement("INSERT INTO cliente VALUES (?, ?, ?, ?)");
        statement.setInt(1, a.getId());
        statement.setString(3, a.getDescricao());
        statement.setString(4, a.getTelefone());
        statement.setString(4, a.getEndereco());
        statement.execute();
        statement.close();
        fechaConexao();
    }
       
    public void apagarCliente(String id) throws Exception {
        conecta();
        statement = connection.prepareStatement("DELETE FROM cliente WHERE ID = ?");
        statement.setString(1, id);
        statement.execute();
        fechaConexao();
    }
            
    public ArrayList<cliente> listCliente() throws Exception {
        ArrayList listaCliente = new ArrayList();
            conecta();
        statement = connection.prepareStatement("SELECT * FROM cliente");
        ResultSet rs = statement.executeQuery();
        ArrayList<cliente> b = new ArrayList<cliente>();
        while (rs.next()) {
            cliente a = new cliente();

                a.setId(rs.getInt("id")); 
                a.setDescricao(rs.getString("descricao")); 
                a.setTelefone(rs.getString("telefone")); 
                a.setEndereco(rs.getString("endereco")); 
                listaCliente.add(a);
            }
        
        rs.close();
        statement.close();
        fechaConexao();
        return b;
    }
}
