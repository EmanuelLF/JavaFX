package conecta;

import java.sql.*;

public class DAOz {
        
    protected Connection connection;
    protected PreparedStatement statement;

    public void conecta() throws Exception {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "");
    }

    public void fechaConexao() throws Exception {
        if (connection != null) {
            connection.close();
        }

        if (statement != null) {
            statement.close();
        }
    }
}